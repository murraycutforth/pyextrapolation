PDE-based Constant Extrapolation
===============================

version number: 0.0.1
author: Murray Cutforth

Overview
--------

A python package for multidimensional extrapolation via the solution of a partial differential equation

Installation / Usage
--------------------

To install use pip:

    $ pip install pyextrapolation


Or clone the repo:

    $ git clone https://github.com/murraycutforth/pyextrapolation.git
    $ python setup.py install
    
Contributing
------------

TBD

Example
-------

TBD